<?php

// Theme Title
add_theme_support('title-tag');