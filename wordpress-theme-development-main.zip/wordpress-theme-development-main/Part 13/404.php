<?php
/*
* The main template file
*/ 
get_header(); ?>

<h1>this is 404 page</h1>


<?php get_footer(); ?>