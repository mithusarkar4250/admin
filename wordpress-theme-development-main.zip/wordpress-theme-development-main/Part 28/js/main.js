jQuery(document).ready(function () {
  jQuery(".slider").bxSlider({
    mode: 'fade',
    captions: true,
  });
});
